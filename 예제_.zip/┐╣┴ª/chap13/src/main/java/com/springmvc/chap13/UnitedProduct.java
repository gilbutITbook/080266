package com.springmvc.chap13;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;



public class UnitedProduct {

	@NotNull
    @Size(min=4, max=10, message="4자~10자 이내로 입력해 주세요")
    private String name;

	@Min(value=0)
    private int price;

	
	private String username;
	private String age;
		   
	private String email;
	    
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	
    
    
    
}
