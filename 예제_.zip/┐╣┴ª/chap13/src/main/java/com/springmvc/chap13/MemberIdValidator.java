package com.springmvc.chap13;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;



public class MemberIdValidator implements ConstraintValidator<MemberId, String>{

   
    private Member member;

    public void initialize(MemberId constraintAnnotation) {
     
    }
   public boolean isValid(String value, ConstraintValidatorContext context) {	  
	     
	      if(value.equals("admin")) {
	         return false;
	      }
	      
	     return true;
    }
}