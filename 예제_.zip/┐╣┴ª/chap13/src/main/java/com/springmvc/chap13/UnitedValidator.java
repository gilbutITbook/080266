package com.springmvc.chap13;

import java.util.HashSet;
import java.util.Set;

import javax.validation.ConstraintViolation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;


public class UnitedValidator implements Validator {

	@Autowired
	private javax.validation.Validator beanValidator;
	

	private Set<Validator> springValidator;

	public UnitedValidator() {
		springValidator = new HashSet<Validator>();
	}
	

	public void setSpringValidator(Set<Validator> springValidator) {
		this.springValidator = springValidator;
	}

	public boolean supports(Class<?> clazz) {
		return UnitedProduct.class.isAssignableFrom(clazz);
	}

	public void validate(Object target, Errors errors) {
		Set<ConstraintViolation<Object>> violations = beanValidator.validate(target);

		for (ConstraintViolation<Object> violation : violations) {
			String propertyPath = violation.getPropertyPath().toString();
			String message = violation.getMessage();
			errors.rejectValue(propertyPath, "", message);
		}
	
		
		
		for(Validator validator: springValidator) {
	         validator.validate(target, errors); 
	      }
			
	}
	
}


