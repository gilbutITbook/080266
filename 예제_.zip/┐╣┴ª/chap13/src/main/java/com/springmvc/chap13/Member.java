package com.springmvc.chap13;


public class Member {

	@MemberId  
    private String memberId;

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
    
    
    
}
