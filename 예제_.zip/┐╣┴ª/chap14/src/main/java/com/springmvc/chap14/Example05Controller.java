package com.springmvc.chap14;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;



@Controller
@RequestMapping("/exam05")
public class Example05Controller {	

	@GetMapping
	public String showForm(@ModelAttribute("Member") Person person) {	
		return "webpage14_03";
	}	
	
	@PutMapping
	public String submit(@ModelAttribute("Member") Person person) {
		
				
		System.out.println(person);
		
		 return "redirect:/exam05";
		
	}
		
}
