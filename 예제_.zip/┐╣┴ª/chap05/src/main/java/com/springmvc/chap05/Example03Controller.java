package com.springmvc.chap05;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Example03Controller {
	
	/*
	@RequestMapping(value = "/exam03", method = RequestMethod.GET)
	public void requestMethod() {
		System.out.println("@RequestMapping �����Դϴ�.");
		System.out.println("�� ��û URL��  /exam03 �Դϴ�.");
	}
	*/
	@RequestMapping("/exam03")
	public void requestMethod() {
		System.out.println("@RequestMapping �����Դϴ�.");
		System.out.println("�� ��û URL��  /exam03 �Դϴ�.");
	}
}